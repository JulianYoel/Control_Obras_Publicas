from util.main import Main

if __name__ == "__main__":
    Main.main()