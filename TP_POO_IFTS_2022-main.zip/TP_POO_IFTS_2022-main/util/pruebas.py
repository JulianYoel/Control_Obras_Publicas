from datetime import date, time, datetime
hoy = date(2020,12,25)
print(hoy)
